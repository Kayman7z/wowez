-- KaymanBuffs: просит бафы у игроков и благодарит в личку, когда тебя бафают.
local ADDON = ...

local DEFAULTS = {
    thanks = true,        -- благодарить за бафы
    ask = true,           -- показывать кнопку просьбы
    thanksMsg = "Спасибо за баф! :)",
    askMsg = "Привет! Бафни, пожалуйста: {buffs} :)",
    thanksCooldown = 120, -- не благодарить одного и того же чаще (сек)
    askCooldown = 60,     -- не просить одного и того же чаще (сек)
    point = nil,          -- позиция кнопки
}

-- Бафы: класс, который даёт; названия (одиночный + групповой, англ. и рус. клиент);
-- ask = просить ли этот баф; mana = нужен только классам с маной.
local BUFFS = {
    { class = "MAGE", label = "Arcane Intellect", ru = "Чародейский интеллект", ask = true, mana = true,
      names = { "Arcane Intellect", "Arcane Brilliance", "Чародейский интеллект", "Чародейская гениальность" } },
    { class = "PRIEST", label = "Fortitude", ru = "Слово силы: Стойкость", ask = true,
      names = { "Power Word: Fortitude", "Prayer of Fortitude", "Слово силы: Стойкость", "Молитва стойкости" } },
    { class = "PRIEST", label = "Divine Spirit", ru = "Божественный дух", ask = true, mana = true,
      names = { "Divine Spirit", "Prayer of Spirit", "Божественный дух", "Молитва духа" } },
    { class = "PRIEST", label = "Shadow Protection", ru = "Защита от тёмной магии",
      names = { "Shadow Protection", "Prayer of Shadow Protection", "Защита от темной магии", "Молитва защиты от темной магии" } },
    { class = "DRUID", label = "Mark of the Wild", ru = "Знак дикой природы", ask = true,
      names = { "Mark of the Wild", "Gift of the Wild", "Знак дикой природы", "Дар дикой природы" } },
    { class = "DRUID", label = "Thorns", ru = "Шипы",
      names = { "Thorns", "Шипы" } },
    { class = "PALADIN", label = "Blessing of Kings", ru = "Благословение королей", ask = true,
      names = { "Blessing of Kings", "Greater Blessing of Kings", "Благословение королей", "Великое благословение королей" } },
    { class = "PALADIN", label = "Blessing of Might", ru = "Благословение могущества", ask = true, physical = true,
      names = { "Blessing of Might", "Greater Blessing of Might", "Благословение могущества", "Великое благословение могущества" } },
    { class = "PALADIN", label = "Blessing of Wisdom", ru = "Благословение мудрости", ask = true, mana = true,
      names = { "Blessing of Wisdom", "Greater Blessing of Wisdom", "Благословение мудрости", "Великое благословение мудрости" } },
    { class = "PALADIN", label = "Blessing of Salvation", ru = "Благословение спасения",
      names = { "Blessing of Salvation", "Greater Blessing of Salvation", "Благословение спасения", "Великое благословение спасения" } },
    { class = "PALADIN", label = "Blessing of Light", ru = "Благословение света",
      names = { "Blessing of Light", "Greater Blessing of Light", "Благословение света", "Великое благословение света" } },
    { class = "PALADIN", label = "Blessing of Sanctuary", ru = "Благословение неприкосновенности",
      names = { "Blessing of Sanctuary", "Greater Blessing of Sanctuary", "Благословение неприкосновенности", "Великое благословение неприкосновенности" } },
}

local MANA_CLASS = { MAGE = true, PRIEST = true, WARLOCK = true, DRUID = true, PALADIN = true, SHAMAN = true, HUNTER = true }
local PHYSICAL_CLASS = { WARRIOR = true, ROGUE = true, HUNTER = true, PALADIN = true, SHAMAN = true, DRUID = true }

local thankable = {} -- название бафа -> класс, который его даёт
for _, b in ipairs(BUFFS) do for _, n in ipairs(b.names) do thankable[n] = b.class end end

local db
local myClass
local lastThanked, lastAsked = {}, {}
local pending = {} -- name -> true, собираем бафы одного человека в одно «спасибо»
local queue = {}   -- очередь «спасибо»: { name = ..., at = ... }
local flushThanks  -- объявлена ниже
local updateButton -- объявлена ниже

local function msg(text)
    DEFAULT_CHAT_FRAME:AddMessage("|cff66ccff[KaymanBuffs]|r " .. tostring(text))
end

local function now() return GetTime() end

local function whisper(target, text)
    if not target or target == "" or not text or text == "" then return end
    local send = (C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage
    local ok, err = pcall(send, text, "WHISPER", nil, target)
    if not ok then msg("|cffff6666Игра не дала отправить шёпот:|r " .. tostring(err)) end
    return ok
end

-- Есть ли на игроке баф из списка названий
local function hasAnyBuff(names)
    local set = {}
    for _, n in ipairs(names) do set[n] = true end
    for i = 1, 40 do
        local name
        if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
            local aura = C_UnitAuras.GetAuraDataByIndex("player", i, "HELPFUL")
            name = aura and aura.name
        else
            name = UnitBuff("player", i)
        end
        if not name then return false end
        if not (issecretvalue and issecretvalue(name)) and set[name] then return true end
    end
    return false
end

local function defaultWants(b)
    if not b.ask then return false end
    if b.mana and not MANA_CLASS[myClass] then return false end
    if b.physical and not PHYSICAL_CLASS[myClass] then return false end
    return true
end

local function wantsBuff(b)
    local v = db and db.askBuffs and db.askBuffs[b.label]
    if v ~= nil then return v end
    return defaultWants(b)
end

-- Каких бафов от этого класса нам не хватает
local function missingFrom(class)
    local list = {}
    for _, b in ipairs(BUFFS) do
        if b.class == class and wantsBuff(b) and not hasAnyBuff(b.names) then
            list[#list + 1] = b.ru or b.label
        end
    end
    return list
end

local function targetName()
    local name, realm = UnitName("target")
    if not name then return nil end
    if realm and realm ~= "" then name = name .. "-" .. realm end
    return name
end

---------------------------------------------------------------- кнопка
local button = CreateFrame("Button", "KaymanBuffsButton", UIParent, "UIPanelButtonTemplate")
button:SetSize(300, 26)
button:SetPoint("CENTER", UIParent, "CENTER", 0, -180)
button:SetMovable(true)
button:RegisterForDrag("LeftButton")
button:SetClampedToScreen(true)
button:Hide()
button:SetScript("OnDragStart", function(self) if IsShiftKeyDown() then self:StartMoving() end end)
button:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local p, _, rp, x, y = self:GetPoint()
    db.point = { p, rp, x, y }
end)
button:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_TOP")
    GameTooltip:AddLine("KaymanBuffs")
    GameTooltip:AddLine("Шепнуть цели просьбу о бафе:", 1, 1, 1)
    for _, l in ipairs(self.buffs or {}) do GameTooltip:AddLine("• " .. l, .6, 1, .6) end
    GameTooltip:AddLine("ПКМ — настройки", .7, .7, .7)
    GameTooltip:AddLine("Shift + перетащить — переместить кнопку", .7, .7, .7)
    GameTooltip:Show()
end)
button:SetScript("OnLeave", function() GameTooltip:Hide() end)

local function askTargetInner(manual)
    if InCombatLockdown() and manual then msg("Ты в бою — попробуй после боя.") end
    local name = targetName()
    if not name or not UnitIsPlayer("target") or UnitIsUnit("target", "player") then
        if manual then msg("Возьми в цель игрока, у которого хочешь попросить баф.") end
        return
    end
    local _, class = UnitClass("target")
    local list = missingFrom(class)
    if #list == 0 then
        if manual then msg("У этого класса нет бафов, которых тебе не хватает.") end
        return
    end
    if lastAsked[name] and now() - lastAsked[name] < db.askCooldown then
        msg("Ты уже просил " .. name .. " недавно, подожди немного.")
        return
    end
    lastAsked[name] = now()
    whisper(name, (db.askMsg:gsub("{buffs}", table.concat(list, ", "))))
    msg("Попросил баф у " .. name .. ": " .. table.concat(list, ", "))
    button:Hide()
end

local function askTarget(manual)
    local ok, err = pcall(askTargetInner, manual)
    if not ok then msg("|cffff6666Ошибка при просьбе:|r " .. tostring(err)) end
end
button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
button:SetScript("OnClick", function(_, mouse)
    if mouse == "RightButton" then KaymanBuffs_ToggleOptions()
    elseif button.mode == "thanks" then flushThanks(true)
    else askTarget(true) end
end)

SLASH_KAYMANBUFFS1 = "/kb"
SLASH_KAYMANBUFFS2 = "/kaymanbuffs"
SlashCmdList.KAYMANBUFFS = function(input)
    if (input or ""):lower():match("^%s*ask") then askTarget(true) else KaymanBuffs_ToggleOptions() end
end

---------------------------------------------------------------- кнопка у миникарты
local mini = CreateFrame("Button", "KaymanBuffsMinimapButton", Minimap)
mini:SetSize(31, 31)
mini:SetFrameStrata("MEDIUM")
mini:SetFrameLevel(8)
mini:RegisterForClicks("LeftButtonUp", "RightButtonUp")
mini:RegisterForDrag("LeftButton")
mini:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

local bg = mini:CreateTexture(nil, "BACKGROUND")
bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
bg:SetSize(20, 20)
bg:SetPoint("TOPLEFT", 7, -5)

local icon = mini:CreateTexture(nil, "ARTWORK")
icon:SetTexture("Interface\\Icons\\Spell_Holy_WordFortitude")
icon:SetSize(17, 17)
icon:SetPoint("TOPLEFT", 7, -6)
icon:SetTexCoord(.08, .92, .08, .92)

local border = mini:CreateTexture(nil, "OVERLAY")
border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
border:SetSize(53, 53)
border:SetPoint("TOPLEFT")

local function placeMini()
    local d = db or KaymanBuffsDB
    local angle = math.rad((d and d.minimapAngle) or 220)
    local r = (Minimap:GetWidth() / 2) + 5
    mini:ClearAllPoints()
    mini:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * r, math.sin(angle) * r)
end

mini:SetScript("OnDragStart", function(self)
    self:SetScript("OnUpdate", function()
        local mx, my = Minimap:GetCenter()
        local scale = Minimap:GetEffectiveScale()
        local cx, cy = GetCursorPosition()
        cx, cy = cx / scale, cy / scale
        if db then db.minimapAngle = math.deg(math.atan2(cy - my, cx - mx)) end
        placeMini()
    end)
end)
mini:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)

mini:SetScript("OnClick", function(_, mouse)
    if mouse == "RightButton" then askTarget(true) else KaymanBuffs_ToggleOptions() end
end)
mini:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:AddLine("|cff66ccffKayman|rBuffs")
    GameTooltip:AddLine("ЛКМ — настройки", 1, 1, 1)
    GameTooltip:AddLine("ПКМ — попросить баф у цели", 1, 1, 1)
    GameTooltip:AddLine("Перетащить — переместить кнопку", .7, .7, .7)
    GameTooltip:Show()
end)
mini:SetScript("OnLeave", function() GameTooltip:Hide() end)

local miniLoader = CreateFrame("Frame")
miniLoader:RegisterEvent("PLAYER_LOGIN")
miniLoader:SetScript("OnEvent", function()
    placeMini()
end)

local function updateButtonInner()
    if db and #queue > 0 and not InCombatLockdown() then
        button.mode = "thanks"
        button.buffs = nil
        button:SetText("Сказать спасибо: " .. Ambiguate(queue[1].name, "short"))
        button:Show()
        return
    end
    button.mode = "ask"
    if not db or not db.ask or InCombatLockdown() then button:Hide() return end
    if not UnitExists("target") or not UnitIsPlayer("target") or UnitIsUnit("target", "player")
        or not UnitIsFriend("player", "target") or UnitIsDeadOrGhost("target") then
        button:Hide() return
    end
    local _, class = UnitClass("target")
    local list = missingFrom(class)
    local name = targetName()
    if #list == 0 or (name and lastAsked[name] and now() - lastAsked[name] < db.askCooldown) then
        button:Hide() return
    end
    button.buffs = list
    button:SetText(#list == 1 and ("Попросить: " .. list[1]) or ("Попросить бафы (" .. #list .. ")"))
    button:Show()
end

local lastUpdErr
updateButton = function()
    local ok, err = pcall(updateButtonInner)
    if not ok then
        button:Hide()
        if err ~= lastUpdErr then lastUpdErr = err; msg("|cffff6666Ошибка кнопки:|r " .. tostring(err)) end
    end
end

---------------------------------------------------------------- спасибо
-- Отправлять чат можно только в ответ на действие игрока (клавиша/клик),
-- поэтому «спасибо» ставится в очередь и уходит при следующем нажатии.

flushThanks = function(force)
    if #queue == 0 or not db then return end
    local t = now()
    for i = 1, #queue do
        local item = queue[i]
        if t - item.at > 90 then
            table.remove(queue, i); pending[item.name] = nil
            return flushThanks(force)
        end
        if force or t - item.at >= 1.5 then -- небольшая пауза, чтобы не выглядело как бот
            table.remove(queue, i); pending[item.name] = nil
            if not (lastThanked[item.name] and t - lastThanked[item.name] < db.thanksCooldown) then
                lastThanked[item.name] = t
                if whisper(item.name, db.thanksMsg) then msg("Сказал спасибо: " .. item.name) end
            end
            if updateButton then updateButton() end
            return -- одно сообщение за одно нажатие
        end
    end
end

local catcher = CreateFrame("Frame", "KaymanBuffsKeyCatcher", UIParent)
catcher:SetSize(1, 1)
catcher:SetPoint("TOPLEFT")
local function setupPropagation()
    if catcher.propagates or InCombatLockdown() then return end
    local ok = pcall(catcher.SetPropagateKeyboardInput, catcher, true)
    if ok and (not catcher.GetPropagateKeyboardInput or catcher:GetPropagateKeyboardInput()) then
        catcher.propagates = true
        catcher:EnableKeyboard(true) -- только когда клавиши точно проходят дальше в игру
    end
end
pcall(setupPropagation)
catcher:SetScript("OnKeyDown", flushThanks)
pcall(WorldFrame.HookScript, WorldFrame, "OnMouseDown", flushThanks)
-- запасной вариант: любой клик по нашим кнопкам тоже отправляет очередь
if type(UseAction) == "function" then pcall(hooksecurefunc, "UseAction", function() pcall(flushThanks) end) end

-- Боевой журнал аддонам в этом клиенте закрыт, поэтому кто наложил баф
-- берём из данных самой ауры (sourceUnit). В бою данные могут быть «секретными» — пропускаем.
local function isSecret(v) return issecretvalue ~= nil and issecretvalue(v) end
local auraExpire = {} -- auraInstanceID -> expirationTime, чтобы ловить повторный баф

local function queueThanksFrom(aura)
    if not db or not db.thanks or type(aura) ~= "table" then return end
    local name, unit = aura.name, aura.sourceUnit
    if isSecret(name) or not name or not thankable[name] then return end
    if isSecret(unit) then unit = nil end
    if unit and UnitIsUnit(unit, "player") then return end -- сам себе
    if not unit then
        -- игра не сказала, кто наложил: ищем подходящего игрока нужного класса в цели/под мышкой/в фокусе
        for _, u in ipairs({ "target", "mouseover", "focus" }) do
            if UnitExists(u) and UnitIsPlayer(u) and not UnitIsUnit(u, "player") then
                local _, c = UnitClass(u)
                if c == thankable[name] then unit = u break end
            end
        end
    end
    if not unit then
        msg("Тебя бафнули (" .. name .. "), но игра не сказала кто. Включи таблички дружественных игроков (Shift+V) или возьми бафера в цель.")
        return
    end
    if not UnitIsPlayer(unit) then return end
    local who, realm = UnitName(unit)
    if not who or isSecret(who) then return end
    if realm and realm ~= "" and not isSecret(realm) then who = who .. "-" .. realm end
    if pending[who] then return end
    if lastThanked[who] and now() - lastThanked[who] < db.thanksCooldown then return end
    pending[who] = true
    queue[#queue + 1] = { name = who, at = now() }
    msg("Скажу спасибо " .. who .. " — нажми любую клавишу или кнопку «Сказать спасибо».")
    if updateButton then updateButton() end
end

local function remember(aura)
    if aura and aura.auraInstanceID and not isSecret(aura.auraInstanceID)
        and not isSecret(aura.expirationTime) then
        auraExpire[aura.auraInstanceID] = aura.expirationTime
    end
end

local function onPlayerAura(info)
    if not C_UnitAuras or not C_UnitAuras.GetAuraDataByAuraInstanceID then return end
    if not info or info.isFullUpdate then
        -- полная перепись бафов (вход, /reload) — просто запоминаем, не благодарим
        wipe(auraExpire)
        for i = 1, 40 do
            local aura = C_UnitAuras.GetAuraDataByIndex("player", i, "HELPFUL")
            if not aura then break end
            remember(aura)
        end
        return
    end
    if info.addedAuras then
        for _, aura in ipairs(info.addedAuras) do
            if aura.isHelpful ~= false then queueThanksFrom(aura) end
            remember(aura)
        end
    end
    if info.updatedAuraInstanceIDs then
        for _, id in ipairs(info.updatedAuraInstanceIDs) do
            local ok, aura = pcall(C_UnitAuras.GetAuraDataByAuraInstanceID, "player", id)
            if ok and aura then
                local old = auraExpire[id]
                local exp = aura.expirationTime
                -- баф обновили заново (время заметно выросло) — тоже повод сказать спасибо
                if old and exp and not isSecret(exp) and exp - old > 30 then queueThanksFrom(aura) end
                remember(aura)
            end
        end
    end
    if info.removedAuraInstanceIDs then
        for _, id in ipairs(info.removedAuraInstanceIDs) do auraExpire[id] = nil end
    end
end

---------------------------------------------------------------- события
local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("PLAYER_TARGET_CHANGED")
f:RegisterEvent("UNIT_AURA")
f:RegisterEvent("PLAYER_REGEN_DISABLED")
f:RegisterEvent("PLAYER_REGEN_ENABLED")
f:SetScript("OnEvent", function(_, event, unit, info)
    if event == "PLAYER_LOGIN" then
        KaymanBuffsDB = KaymanBuffsDB or {}
        db = KaymanBuffsDB
        if db.askMsg == "Hi! Could you buff me with {buffs}, please? / Привет! Можно баф? :)" then db.askMsg = nil end
        if db.thanksMsg == "Thanks for the buff! / Спасибо за баф! :)" then db.thanksMsg = nil end
        for k, v in pairs(DEFAULTS) do if db[k] == nil then db[k] = v end end
        _, myClass = UnitClass("player")
        if db.point then
            button:ClearAllPoints()
            button:SetPoint(db.point[1], UIParent, db.point[2], db.point[3], db.point[4])
        end
        msg("загружен. Настройки: /kb")
        pcall(setupPropagation)
        pcall(onPlayerAura, nil)
    elseif event == "PLAYER_REGEN_ENABLED" then
        pcall(setupPropagation); updateButton()
    elseif event == "UNIT_AURA" then
        if unit == "player" then
            pcall(onPlayerAura, info)
            updateButton()
        end
    else
        updateButton()
    end
end)

---------------------------------------------------------------- окно настроек
local opt
local GOLD, GRAY = { 1, .82, 0 }, { .75, .75, .75 }

local function classColor(class)
    local c = RAID_CLASS_COLORS and RAID_CLASS_COLORS[class]
    if c then return c.r, c.g, c.b end
    return 1, 1, 1
end

local CLASS_RU = { MAGE = "Маг", PRIEST = "Жрец", DRUID = "Друид", PALADIN = "Паладин" }

local function text(parent, str, font, x, y, color)
    local t = parent:CreateFontString(nil, "OVERLAY", font or "GameFontHighlight")
    t:SetPoint("TOPLEFT", x, y)
    t:SetJustifyH("LEFT")
    t:SetText(str)
    if color then t:SetTextColor(color[1], color[2], color[3]) end
    return t
end

local function header(parent, str, y)
    local t = text(parent, str, "GameFontNormalLarge", 18, y, GOLD)
    local line = parent:CreateTexture(nil, "ARTWORK")
    line:SetColorTexture(1, .82, 0, .35)
    line:SetHeight(1)
    line:SetPoint("TOPLEFT", 18, y - 22)
    line:SetPoint("TOPRIGHT", -18, y - 22)
    return t
end

local function checkbox(parent, label, x, y, get, set, tip)
    local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    cb:SetSize(26, 26)
    cb:SetPoint("TOPLEFT", x, y)
    local t = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    t:SetPoint("LEFT", cb, "RIGHT", 2, 1)
    t:SetText(label)
    cb.label = t
    cb:SetHitRectInsets(0, -(t:GetStringWidth() + 6), 0, 0)
    cb:SetScript("OnClick", function(self) set(self:GetChecked() and true or false) end)
    if tip then
        cb:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine(label)
            GameTooltip:AddLine(tip, 1, 1, 1, true)
            GameTooltip:Show()
        end)
        cb:SetScript("OnLeave", function() GameTooltip:Hide() end)
    end
    cb.refresh = function() cb:SetChecked(get() and true or false) end
    return cb
end

local function editbox(parent, x, y, width, numeric, get, set)
    local e = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
    e:SetSize(width, 22)
    e:SetPoint("TOPLEFT", x + 6, y)
    e:SetAutoFocus(false)
    e:SetFontObject("ChatFontNormal")
    e:SetMaxLetters(numeric and 4 or 255)
    if numeric then e:SetNumeric(true) end
    local function save(self)
        local v = self:GetText()
        if numeric then
            v = tonumber(v)
            if not v or v < 0 then self:SetText(tostring(get())) return end
        elseif v == "" then
            self:SetText(get()) return
        end
        set(v)
    end
    e:SetScript("OnEnterPressed", function(self) save(self); self:ClearFocus() end)
    e:SetScript("OnEscapePressed", function(self) self:SetText(tostring(get())); self:ClearFocus() end)
    e:SetScript("OnEditFocusLost", save)
    e.refresh = function() e:SetText(tostring(get())); e:SetCursorPosition(0) end
    return e
end

local function pushButton(parent, label, width, onClick)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(width, 24)
    b:SetText(label)
    b:SetScript("OnClick", onClick)
    return b
end

local function buildOptions()
    local ok, frame = pcall(CreateFrame, "Frame", "KaymanBuffsOptions", UIParent, "BasicFrameTemplateWithInset")
    if not ok or not frame then
        frame = CreateFrame("Frame", "KaymanBuffsOptions", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
        if frame.SetBackdrop then
            frame:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
                edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", tile = true, tileSize = 32, edgeSize = 32,
                insets = { left = 8, right = 8, top = 8, bottom = 8 } })
        end
        local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT", -4, -4)
    end
    frame:SetSize(460, 650)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata("DIALOG")
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:SetClampedToScreen(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    tinsert(UISpecialFrames, "KaymanBuffsOptions") -- закрытие по Esc
    frame:Hide()

    local title = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    title:SetPoint("TOP", 0, -6)
    title:SetText("|cff66ccffKayman|rBuffs — настройки")

    local controls = {}
    local function add(c) controls[#controls + 1] = c; return c end

    -- Благодарность
    header(frame, "Благодарность", -34)
    add(checkbox(frame, "Писать «спасибо» в личку, когда меня бафают", 18, -64,
        function() return db.thanks end, function(v) db.thanks = v end,
        "Через 1,5–3 секунды после бафа игроку уйдёт шёпот с текстом ниже. Хилки и хоты не считаются."))
    text(frame, "Текст сообщения:", "GameFontNormalSmall", 22, -96, GRAY)
    add(editbox(frame, 18, -110, 410, false, function() return db.thanksMsg end, function(v) db.thanksMsg = v end))
    text(frame, "Одному игроку не чаще раза в", "GameFontHighlightSmall", 22, -144)
    add(editbox(frame, 200, -139, 40, true, function() return db.thanksCooldown end, function(v) db.thanksCooldown = v end))
    text(frame, "сек", "GameFontHighlightSmall", 254, -144)

    -- Просьба
    header(frame, "Просьба о бафе", -172)
    add(checkbox(frame, "Показывать кнопку «Попросить», когда беру в цель бафера", 18, -202,
        function() return db.ask end, function(v) db.ask = v; updateButton() end,
        "Кнопка появляется, если у цели есть баф, которого на тебе нет. В бою прячется."))
    text(frame, "Текст просьбы ({buffs} — подставится список бафов):", "GameFontNormalSmall", 22, -234, GRAY)
    add(editbox(frame, 18, -248, 410, false, function() return db.askMsg end, function(v) db.askMsg = v end))
    text(frame, "Одного игрока не чаще раза в", "GameFontHighlightSmall", 22, -282)
    add(editbox(frame, 200, -277, 40, true, function() return db.askCooldown end, function(v) db.askCooldown = v end))
    text(frame, "сек", "GameFontHighlightSmall", 254, -282)

    -- Бафы
    header(frame, "Какие бафы просить", -310)
    local y, col = -340, 0
    local lastClass
    local x0 = { 18, 232 }
    local rows = { 0, 0 }
    -- раскладываем по классам в две колонки: Маг+Жрец слева, Друид+Паладин справа
    local columnOf = { MAGE = 1, PRIEST = 1, DRUID = 2, PALADIN = 2 }
    local classHeaderDone = {}
    for _, b in ipairs(BUFFS) do
        local c = columnOf[b.class] or 1
        local cy = y - rows[c] * 22
        if not classHeaderDone[b.class] then
            local t = text(frame, CLASS_RU[b.class] or b.class, "GameFontNormal", x0[c] + 4, cy - 4)
            t:SetTextColor(classColor(b.class))
            classHeaderDone[b.class] = true
            rows[c] = rows[c] + 1
            cy = y - rows[c] * 22
        end
        add(checkbox(frame, b.ru or b.label, x0[c], cy,
            function() return wantsBuff(b) end,
            function(v) db.askBuffs = db.askBuffs or {}; db.askBuffs[b.label] = v; updateButton() end))
        rows[c] = rows[c] + 1
    end
    text(frame, "По умолчанию отмечено то, что полезно твоему классу.", "GameFontDisableSmall", 22,
        y - math.max(rows[1], rows[2]) * 22 - 4)

    -- Нижние кнопки
    local test = pushButton(frame, "Проверить", 120, function()
        msg("Так будет выглядеть «спасибо»: |cffff80ff" .. db.thanksMsg .. "|r")
        msg("Так будет выглядеть просьба: |cffff80ff"
            .. db.askMsg:gsub("{buffs}", "Знак дикой природы, Слово силы: Стойкость") .. "|r")
    end)
    test:SetPoint("BOTTOMLEFT", 18, 16)
    local reset = pushButton(frame, "Сбросить", 120, function()
        for k, v in pairs(DEFAULTS) do db[k] = v end
        db.askBuffs = nil
        button:ClearAllPoints()
        button:SetPoint("CENTER", UIParent, "CENTER", 0, -180)
        for _, c in ipairs(controls) do c.refresh() end
        updateButton()
        msg("Настройки сброшены.")
    end)
    reset:SetPoint("BOTTOM", 0, 16)
    local close = pushButton(frame, "Закрыть", 120, function() frame:Hide() end)
    close:SetPoint("BOTTOMRIGHT", -18, 16)

    frame:SetScript("OnShow", function() for _, c in ipairs(controls) do c.refresh() end end)
    return frame
end

function KaymanBuffs_ToggleOptions()
    if not db then return end
    opt = opt or buildOptions()
    opt:SetShown(not opt:IsShown())
end

