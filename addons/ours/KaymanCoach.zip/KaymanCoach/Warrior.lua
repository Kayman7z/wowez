-- Kayman Coach — Воин (танк/защита, прокачка и квесты в открытом мире)
local _, ns = ...
local okW, errW = pcall(function()

local BATTLE_SHOUT, CHARGE, REND, HEROIC, THUNDER, HAMSTRING = 6673, 100, 772, 78, 6343, 1715
local BLOODRAGE, SUNDER, OVERPOWER, SHIELD_BASH, DEMO = 2687, 7386, 7384, 72, 1160
local REVENGE, SHIELD_BLOCK, EXECUTE, LAST_STAND, CLEAVE = 6572, 2565, 5308, 12975, 845
local SHIELD_SLAM, CONCUSSION, BATTLE_STANCE, DEF_STANCE, ATTACK = 23922, 12809, 2457, 71, 6603
local VICTORY_RUSH = 34428   -- в Forever с 20 ур.: бесплатно, после убийства, лечит

local NO_BLEED = { Elemental = true, Mechanical = true, ["Элементаль"] = true, ["Механизм"] = true }
local HUMANOID = { Humanoid = true, ["Гуманоид"] = true }

-- Стоимость умений в ярости (классика) — по ним оцениваем ярость в бою
local COSTS = {
    [REVENGE] = 5, [OVERPOWER] = 5, [REND] = 10, [HAMSTRING] = 10, [SHIELD_BLOCK] = 10, [SHIELD_BASH] = 10,
    [DEMO] = 10, [BATTLE_SHOUT] = 10, [HEROIC] = 15, [SUNDER] = 15, [EXECUTE] = 15, [CONCUSSION] = 15,
    [THUNDER] = 20, [CLEAVE] = 20, [SHIELD_SLAM] = 20,
}

-- Можно ли слить ярость в Удар героя/Рассекающий, не оставшись без Реванша и Удара щитом.
-- Вне боя ярость видна точно (держим запас 15). В бою она скрыта: тратим, только если хватает
-- на сам удар и в ближайшие пару секунд не придёт Реванш (иначе копим на него).
local function RageToSpare(c, cost)
    if c.power then return c.power >= cost + 15 end
    if c.rageMin < cost then return false end
    local revengeSoon = c:Known(REVENGE) and c:CD(REVENGE) < 2 and c.stance == 2
    return not revengeSoon or c.rageMin >= cost + 5
end

local function SunderStacks(c) local _, n = c:Debuff(SUNDER); return n or 0 end
local function Tank(c) return c.stance == 2 end

local rules = {
    -- ===== Начало боя =====
    { id = BATTLE_STANCE, why = "встань в Боевую стойку, чтобы начать бой Рывком",
      when = function(c) return c.hasTarget and not c.combat and not c.tCombat and c.stance ~= 1
             and c:Known(CHARGE) and c:CD(CHARGE) == 0 and c:Range(CHARGE) == true end },
    { id = CHARGE, why = "начни бой: оглушение + ярость",
      when = function(c) return c.hasTarget and not c.combat and c:Ready(CHARGE) and c:Range(CHARGE) == true end },
    { id = BATTLE_SHOUT, why = "нет Боевого крика — +сила атаки",
      when = function(c) local has, _, left = c:Buff(BATTLE_SHOUT)
             return (not has or left < 8) and c:Ready(BATTLE_SHOUT) and (c.combat or c.hasTarget) end },

    -- ===== Сбить каст / выжить =====
    { id = SHIELD_BASH, why = "моб кастует — сбей заклинание!",
      when = function(c) return c.tCasting and c.shield and c:Ready(SHIELD_BASH) and c:Range(SHIELD_BASH) == true end },
    { id = LAST_STAND, why = "мало здоровья — +30% HP на 20 сек",
      when = function(c) return c.combat and c.hp < 30 and c:Ready(LAST_STAND) end },
    { id = DEF_STANCE, why = function(c) return c.enemies >= 2 and "несколько мобов — защитная стойка" or "мало HP — защитная стойка" end,
      when = function(c) return c.combat and c.stance ~= 2 and (c.power == nil or c.power <= 25) and c.shield
             and (c.enemies >= 2 or c.hp < 55 or c.elite) and not c:Ready(OVERPOWER) end },

    -- ===== Бесплатное и процы =====
    { id = VICTORY_RUSH, why = "бесплатный удар + лечение (после убийства моба)",
      when = function(c) return c.hasTarget and c:Ready(VICTORY_RUSH) and c:Range(VICTORY_RUSH) == true end },
    { id = REVENGE, why = "Реванш горит — главный удар Защиты",
      when = function(c) return c.hasTarget and c:Ready(REVENGE) and c:Range(REVENGE) == true end },
    { id = OVERPOWER, why = "моб уклонился — Превосходство нельзя пропускать",
      when = function(c) return c.hasTarget and c:Ready(OVERPOWER) and c:Range(OVERPOWER) == true end },
    { id = EXECUTE, why = "у моба < 20% HP — добивай",
      when = function(c) return c.hasTarget and c:Ready(EXECUTE) end },
    { id = SHIELD_SLAM, why = "мощный удар щитом",
      when = function(c) return c.hasTarget and c:Ready(SHIELD_SLAM) and c:Range(SHIELD_SLAM) == true end },

    -- ===== Защитная стойка: сначала дебаффы, потом крутим Реванш =====
    { id = DEMO, why = "в начале боя: меньше урона по тебе + угроза по всем рядом",
      when = function(c) return c.combat and c.hasTarget and Tank(c) and not c:Debuff(DEMO) and c.thp > 30
             and c:Ready(DEMO) end },
    { id = THUNDER, why = "2+ моба рядом — урон по всем и замедление",
      when = function(c) return c.combat and c.enemies >= 2 and not c:Debuff(THUNDER) and c:Ready(THUNDER) end },
    { id = SUNDER, why = function(c) return "танк: Раскол брони, стаки " .. SunderStacks(c) .. "/5" end,
      when = function(c) return c.hasTarget and Tank(c) and SunderStacks(c) < 2 and c:Ready(SUNDER)
             and c:Range(SUNDER) == true end },
    -- Блок щитом включает Реванш. Не советуем, пока Блок уже висит на тебе.
    { id = SHIELD_BLOCK, why = "Блок щитом → заблокируешь удар → загорится Реванш",
      when = function(c) return c.combat and c.hasTarget and Tank(c) and c.shield
             and c:Known(REVENGE) and not c:Ready(REVENGE) and c:CD(REVENGE) < 1
             and not c:Buff(SHIELD_BLOCK) and c:Ready(SHIELD_BLOCK) end },
    { id = REND, why = "кровотечение — урон со временем",
      when = function(c) return c.hasTarget and not NO_BLEED[c.tType] and c.thp > 50 and not c:Debuff(REND)
             and c.stance ~= 3 and c:Ready(REND) and c:Range(REND) == true end },
    { id = THUNDER, why = "замедли атаки моба (меньше урона по тебе)",
      when = function(c) return c.combat and c.hasTarget and Tank(c) and not c:Debuff(THUNDER) and c.thp > 30
             and RageToSpare(c, 20) and c:Ready(THUNDER) end },
    { id = SUNDER, why = function(c) return "танк: Раскол брони, стаки " .. SunderStacks(c) .. "/5" end,
      when = function(c) return c.hasTarget and Tank(c) and SunderStacks(c) < 5 and c:Ready(SUNDER)
             and c:Range(SUNDER) == true end },

    -- ===== Боевая стойка / прочее =====
    { id = HAMSTRING, why = "гуманоид скоро побежит — замедли",
      when = function(c) return c.hasTarget and HUMANOID[c.tType] and c.thp < 35 and not c:Debuff(HAMSTRING)
             and c:Ready(HAMSTRING) and c:Range(HAMSTRING) == true end },
    { id = DEMO, why = function(c) return c.enemies >= 2 and "2+ моба — меньше их урон" or "сильный моб — ослабь его атаку" end,
      when = function(c) return c.combat and c.hasTarget and not c:Debuff(DEMO) and c.thp > 40
             and (c.enemies >= 2 or c.elite or c.tLevelDiff >= 2) and c:Ready(DEMO) end },
    { id = BLOODRAGE, why = "мало ярости — Кровавая ярость",
      when = function(c) return c.combat and c.rageMin < 10 and c.hp > 40 and c:Ready(BLOODRAGE) end },
    { id = CONCUSSION, why = "оглушение — моб 5 сек не бьёт",
      when = function(c) return c.hasTarget and c.combat and c:Ready(CONCUSSION) and c:Range(CONCUSSION) == true end },
    { id = SUNDER, why = "сильный моб — снижай броню",
      when = function(c) return c.hasTarget and (c.elite or c.tLevelDiff >= 2) and SunderStacks(c) < 3 and c.thp > 30
             and c:Ready(SUNDER) end },
    { id = CLEAVE, why = "2+ моба — бей по двоим",
      when = function(c) return c.enemies >= 2 and RageToSpare(c, 20) and not c:Queued(CLEAVE) and not c:Queued(HEROIC)
             and c:Ready(CLEAVE) end },
    { id = HEROIC, why = "ярости хватает с запасом — слей в Удар героя",
      when = function(c) return c.hasTarget and c.combat and RageToSpare(c, 15) and not c:Queued(HEROIC)
             and not c:Queued(CLEAVE) and c:Ready(HEROIC) end },

    -- Атаку советуем, только если автоатака НЕ идёт (повторное нажатие её выключает)
    { id = ATTACK, why = "включи автоатаку",
      when = function(c) return c.hasTarget and c.combat and not c.autoAttack end },
}

-- Таланты Защиты для WoW Forever (дерево в Forever переделано, классические гайды не подходят).
-- Источник: гайд KallTorak «Protection Warrior Guide — Leveling & End Game», Mobalytics (WoW Forever).
local SS, IR, ITC, LS = "Специализация на щите (Shield Specialization)", "Улучшенный Реванш (Improved Revenge)",
                        "Улучшенный Удар грома (Improved Thunder Clap)", "Ни шагу назад (Last Stand)"
local MOD, IB, VAN = "Мастер обороны (Master of Defense)", "Улучшенная Кровавая ярость (Improved Bloodrage)", "Авангард (Vanguard)"
local ISA, CB = "Улучшенный Раскол брони (Improved Sunder Armor)", "Оглушающий удар (Concussion Blow)"
local talents = {
    tabName = "Защита",
    source = "KallTorak, Mobalytics, WoW Forever",
    byLevel = {
        [10] = SS, [11] = SS, [12] = SS, [13] = SS, [14] = SS,
        [15] = IR, [16] = IR, [17] = IR,
        [18] = ITC, [19] = ITC,
        [20] = LS,
        [21] = MOD, [22] = MOD,
        [23] = ITC,
        [24] = IB,
        [25] = VAN,
        [26] = IB,
        [27] = ISA, [28] = ISA, [29] = ISA,
        [30] = CB,
    },
}

-- Базовые кулдауны (сек) — в бою Forever их прячет, считаем сами
local COOLDOWNS = {
    [CHARGE] = 15, [BLOODRAGE] = 60, [REVENGE] = 5, [OVERPOWER] = 5, [SHIELD_BASH] = 12,
    [SHIELD_BLOCK] = 5, [THUNDER] = 4, [LAST_STAND] = 600, [CONCUSSION] = 45, [SHIELD_SLAM] = 6,
}
-- Длительность баффов/дебаффов (сек) — тоже для боя
local AURAS = {
    [BATTLE_SHOUT] = 120, [REND] = 15, [HAMSTRING] = 15, [DEMO] = 30, [THUNDER] = 10, [SUNDER] = 30,
    [SHIELD_BLOCK] = 7,   -- бафф 7 сек или 2 блока (тултип Forever): пока висит, Блок повторно не советуем
}

ns.classes.WARRIOR = {
    costs = COSTS,
    cooldowns = COOLDOWNS,
    auras = AURAS,
    title = "Воин-танк (защита, квесты)",
    rules = rules,
    talents = talents,
    meleeProbe = HAMSTRING,   -- по дальности этого умения считаем мобов в мили
}

end)
if not okW then ns.loadError = "Warrior.lua: " .. tostring(errW); print("|cffff4040Kayman Coach (Warrior) ошибка:|r " .. tostring(errW)) end
