-- Kayman Coach — меню настроек (окно, кнопка у миникарты, пункт в настройках игры)
local ADDON, ns = ...

local function MakeFrame(kind, name, parent, template)
    local ok, f = pcall(CreateFrame, kind, name, parent, template)
    if ok and f then return f end
    return CreateFrame(kind, name, parent, BackdropTemplateMixin and "BackdropTemplate" or nil)
end

local opt          -- окно настроек
local checks = {}  -- галочки для обновления

local OPTIONS = {
    { key = "glow",       text = "Подсвечивать нужную кнопку на панели" },
    { key = "reason",     text = "Пояснение под иконкой (почему жать)" },
    { key = "onlyCombat", text = "Показывать только в бою" },
    { key = "talents",    text = "Подсказки талантов при новом уровне" },
    { key = "record",     text = "Записывать бои (для разбора)" },
    { key = "blizzard",   text = "Учитывать встроенный помощник Blizzard (если есть)" },
}

local function Refresh()
    if not opt or not ns.DB then return end
    for key, cb in pairs(checks) do cb:SetChecked(ns.DB[key] and true or false) end
    opt.lockBtn:SetText(ns.DB.locked and "Двигать окно подсказки" or "Закрепить окно")
    opt.scaleText:SetText(string.format("Размер: %d%%", math.floor((ns.DB.scale or 1) * 100 + 0.5)))
    local n = ns.DB.fights and #ns.DB.fights or 0
    opt.fightsText:SetText("Записано боёв: " .. n .. " (сохраняются после /reload или выхода)")
end

local function SetLocked(locked)
    ns.DB.locked = locked
    ns.frame:EnableMouse(not locked)
    if not locked then ns.frame:Show() end
end

local function SetScale(v)
    v = math.max(0.5, math.min(2, v))
    ns.DB.scale = v
    ns.frame:SetScale(v)
end

local function Button(parent, text, w, onClick)
    local b = MakeFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(w, 24)
    b:SetText(text)
    if type(b.GetFontString) == "function" and not b:GetFontString() then
        local fs = b:CreateFontString(nil, "OVERLAY", "GameFontNormal"); fs:SetPoint("CENTER"); b:SetFontString(fs); b:SetText(text)
    end
    b:SetScript("OnClick", onClick)
    return b
end

local function BuildOptions()
    if opt then return end
    opt = MakeFrame("Frame", "KaymanCoachOptions", UIParent, "BasicFrameTemplateWithInset")
    opt:SetSize(440, 470)
    opt:SetPoint("CENTER")
    opt:SetFrameStrata("DIALOG")
    opt:SetMovable(true); opt:EnableMouse(true); opt:SetClampedToScreen(true)
    opt:RegisterForDrag("LeftButton")
    opt:SetScript("OnDragStart", opt.StartMoving)
    opt:SetScript("OnDragStop", opt.StopMovingOrSizing)
    if type(opt.CloseButton) ~= "table" and type(opt.TitleBg) ~= "table" then
        -- шаблон не нашёлся — простой фон
        if opt.SetBackdrop then
            opt:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
                              edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
                              tile = true, tileSize = 32, edgeSize = 32,
                              insets = { left = 8, right = 8, top = 8, bottom = 8 } })
        end
        local close = Button(opt, "X", 24, function() opt:Hide() end)
        close:SetPoint("TOPRIGHT", -8, -8)
    end
    tinsert(UISpecialFrames, "KaymanCoachOptions")   -- закрывается по Esc

    local title = opt:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    title:SetPoint("TOP", 0, -6)
    title:SetText("|cffff4040Kayman|r Coach — настройки")

    local y = -36
    for _, o in ipairs(OPTIONS) do
        local cb = MakeFrame("CheckButton", nil, opt, "UICheckButtonTemplate")
        cb:SetSize(26, 26)
        cb:SetPoint("TOPLEFT", 16, y)
        local label = (type(cb.Text) == "table" and cb.Text) or (type(cb.text) == "table" and cb.text)
            or cb:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        label:ClearAllPoints(); label:SetPoint("LEFT", cb, "RIGHT", 4, 0)
        label:SetText(o.text)
        cb:SetScript("OnClick", function(self)
            ns.DB[o.key] = self:GetChecked() and true or false
            if o.key == "talents" and ns.TalentHint then ns.TalentHint() end
        end)
        checks[o.key] = cb
        y = y - 30
    end

    -- Окно подсказки: двигать / размер
    y = y - 10
    opt.lockBtn = Button(opt, "Двигать окно подсказки", 200, function()
        SetLocked(not ns.DB.locked); Refresh()
    end)
    opt.lockBtn:SetPoint("TOPLEFT", 16, y)

    opt.scaleText = opt:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    opt.scaleText:SetPoint("LEFT", opt.lockBtn, "RIGHT", 16, 0)
    local minus = Button(opt, "−", 28, function() SetScale((ns.DB.scale or 1) - 0.1); Refresh() end)
    minus:SetPoint("LEFT", opt.scaleText, "RIGHT", 8, 0)
    local plus = Button(opt, "+", 28, function() SetScale((ns.DB.scale or 1) + 0.1); Refresh() end)
    plus:SetPoint("LEFT", minus, "RIGHT", 2, 0)

    -- Таланты
    y = y - 40
    local planBtn = Button(opt, "План талантов (в чат)", 200, function() ns.Slash("plan") end)
    planBtn:SetPoint("TOPLEFT", 16, y)
    local diagBtn = Button(opt, "Диагностика (в чат)", 190, function() ns.Slash("debug") end)
    diagBtn:SetPoint("LEFT", planBtn, "RIGHT", 10, 0)

    -- Записи боёв
    y = y - 40
    opt.fightsText = opt:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    opt.fightsText:SetPoint("TOPLEFT", 18, y)
    y = y - 22
    local clearBtn = Button(opt, "Стереть записи боёв", 200, function() ns.Slash("clear"); Refresh() end)
    clearBtn:SetPoint("TOPLEFT", 16, y)
    local reloadBtn = Button(opt, "Сохранить (/reload)", 190, function() ReloadUI() end)
    reloadBtn:SetPoint("LEFT", clearBtn, "RIGHT", 10, 0)

    -- Подсказка про файл
    y = y - 36
    local help = opt:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    help:SetPoint("TOPLEFT", 18, y)
    help:SetWidth(400); help:SetJustifyH("LEFT")
    help:SetText("Записи боёв лежат в файле:\nWTF\\Account\\ИМЯ\\SavedVariables\\KaymanCoach.lua\n" ..
                 "Кнопка у миникарты: ЛКМ — это меню, перетаскивание — переместить кнопку.\n" ..
                 "Меню также открывается командой /kc.")

    opt:SetScript("OnShow", Refresh)
    opt:Hide()
end

function ns.ToggleOptions()
    if not ns.DB then return end
    BuildOptions()
    if opt:IsShown() then opt:Hide() else opt:Show(); Refresh() end
end

---------------------------------------------------------------------------
-- Кнопка у миникарты
---------------------------------------------------------------------------
local function UpdateMinimapPos(btn)
    local a = math.rad(ns.DB.minimapAngle or 210)
    btn:ClearAllPoints()
    btn:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * 80, math.sin(a) * 80)
end

local function BuildMinimapButton()
    if not Minimap or ns.DB.hideMinimap then return end
    local btn = CreateFrame("Button", "KaymanCoachMinimapButton", Minimap)
    btn:SetSize(31, 31)
    btn:SetFrameStrata("MEDIUM"); btn:SetFrameLevel(8)
    btn:RegisterForClicks("AnyUp"); btn:RegisterForDrag("LeftButton")

    local icon = btn:CreateTexture(nil, "BACKGROUND")
    icon:SetTexture("Interface\\Icons\\INV_Shield_06")
    icon:SetSize(20, 20); icon:SetPoint("CENTER", 0, 1)
    local border = btn:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    border:SetSize(53, 53); border:SetPoint("TOPLEFT")
    btn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    btn:SetScript("OnClick", function() ns.ToggleOptions() end)
    btn:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local s = Minimap:GetEffectiveScale()
            ns.DB.minimapAngle = math.deg(math.atan2(cy / s - my, cx / s - mx))
            UpdateMinimapPos(self)
        end)
    end)
    btn:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    btn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("|cffff4040Kayman|r Coach")
        GameTooltip:AddLine("ЛКМ — настройки", 1, 1, 1)
        GameTooltip:AddLine("Перетащи — переместить", 1, 1, 1)
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    UpdateMinimapPos(btn)
end

---------------------------------------------------------------------------
-- Пункт в «Настройки → Модификации» (если клиент поддерживает)
---------------------------------------------------------------------------
local function RegisterInGameSettings()
    if not (Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory) then return end
    local panel = CreateFrame("Frame")
    panel.name = "Kayman Coach"
    local t = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    t:SetPoint("TOPLEFT", 16, -16); t:SetText("|cffff4040Kayman|r Coach")
    local b = Button(panel, "Открыть настройки Kayman Coach", 260, function()
        if SettingsPanel and SettingsPanel.Close then pcall(SettingsPanel.Close, SettingsPanel) end
        ns.ToggleOptions()
    end)
    b:SetPoint("TOPLEFT", 16, -50)
    local category = Settings.RegisterCanvasLayoutCategory(panel, "Kayman Coach")
    Settings.RegisterAddOnCategory(category)
end

ns.OnDBReady = function()
    pcall(BuildMinimapButton)
    pcall(RegisterInGameSettings)
end
-- если файл загрузился уже после ADDON_LOADED (на всякий случай)
if ns.DB then ns.OnDBReady() end
