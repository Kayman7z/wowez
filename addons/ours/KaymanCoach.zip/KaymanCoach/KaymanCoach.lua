-- Kayman Coach — ядро: подсказка «жми сейчас», клавиша, подсветка кнопки, таланты.
local ADDON, ns = ...
ns.classes = {}

-- Команда регистрируется самой первой: даже если дальше что-то сломается, /coach покажет ошибку
SLASH_KAYMANCOACH1 = "/coach"
SLASH_KAYMANCOACH2 = "/коуч"
SLASH_KAYMANCOACH3 = "/kc"
SlashCmdList.KAYMANCOACH = function(msg)
    if ns.Slash then
        local ok, err = pcall(ns.Slash, msg)
        if not ok then print("|cffff4040Kayman Coach ошибка:|r " .. tostring(err)) end
    else
        print("|cffff4040Kayman Coach не загрузился:|r " .. tostring(ns.loadError or "неизвестная ошибка"))
    end
end

local function LoadErr(e)
    return tostring(e) .. "\n" .. (debugstack and debugstack(2, 4, 0) or "")
end

local okLoad, errLoad = xpcall(function()

local DB
local defaults = { locked = true, scale = 1, point = { "CENTER", "UIParent", "CENTER", 0, -170 },
                   glow = true, reason = true, onlyCombat = false, talents = true, blizzard = true, record = true }

---------------------------------------------------------------------------
-- Совместимость API
---------------------------------------------------------------------------
local function SpellName(id)
    if GetSpellInfo then return (GetSpellInfo(id)) end
    local i = C_Spell and C_Spell.GetSpellInfo(id); return i and i.name
end
local function SpellIcon(id)
    if GetSpellTexture then return GetSpellTexture(id) end
    local i = C_Spell and C_Spell.GetSpellInfo(id); return i and i.iconID
end
local function Usable(name)
    if IsUsableSpell then return IsUsableSpell(name) end
    return C_Spell.IsSpellUsable(name)
end
-- В бою Forever прячет кулдауны («секрет»), поэтому параллельно считаем их сами по твоим кастам
local lastCast = {}          -- имя заклинания -> время последнего успешного каста
local lastCastOnTarget = {}  -- то же, но сбрасывается при смене цели (для дебаффов)
local sunderStacks = 0
ns.CD_BY_ID = {}             -- id -> базовый кулдаун (заполняет файл класса)
local cdByName = {}

local function TrackedCD(name)
    local cd, t = cdByName[name], lastCast[name]
    if not cd or not t then return 0 end
    local left = t + cd - GetTime()
    return left > 0 and left or 0
end

local function CooldownLeft(name)
    local ok, s, d = pcall(function()
        if GetSpellCooldown then return GetSpellCooldown(name) end
        local c = C_Spell.GetSpellCooldown(name); if c then return c.startTime, c.duration end
    end)
    local secret = issecretvalue and ((s ~= nil and issecretvalue(s)) or (d ~= nil and issecretvalue(d)))
    if not ok or secret then return TrackedCD(name) end
    if not s or s == 0 or not d or d <= 1.5 then return 0 end   -- ГКД не считаем
    return s + d - GetTime()
end
local function InRange(name, unit)
    if C_Spell and C_Spell.IsSpellInRange then return C_Spell.IsSpellInRange(name, unit) end
    local r = IsSpellInRange(name, unit); if r == nil then return nil end; return r == 1
end
ns.InRange = InRange

-- Известные заклинания (по книге заклинаний, любые ранги)
local known = {}
local function ScanSpellbook()
    wipe(known)
    if C_SpellBook and C_SpellBook.GetNumSpellBookSkillLines then
        for t = 1, C_SpellBook.GetNumSpellBookSkillLines() do
            local line = C_SpellBook.GetSpellBookSkillLineInfo(t)
            for i = line.itemIndexOffset + 1, line.itemIndexOffset + line.numSpellBookItems do
                local n = C_SpellBook.GetSpellBookItemName(i, Enum.SpellBookSpellBank.Player)
                if n then known[n] = true end
            end
        end
    else
        for t = 1, GetNumSpellTabs() do
            local _, _, offset, num = GetSpellTabInfo(t)
            for i = offset + 1, offset + num do
                local n = GetSpellBookItemName(i, BOOKTYPE_SPELL or "spell")
                if n then known[n] = true end
            end
        end
    end
end

-- Ауры: возвращает (есть, стаки, осталось сек)
local function Aura(unit, name, filter)
    for i = 1, 40 do
        local n, count, expires, _
        if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
            local a = C_UnitAuras.GetAuraDataByIndex(unit, i, filter)
            if not a then break end
            n, count, expires = a.name, a.applications, a.expirationTime
        else
            local fn = (filter == "HARMFUL") and UnitDebuff or UnitBuff
            n, _, count, _, _, expires = fn(unit, i)
            if not n then break end
        end
        if n == name then
            local left = (expires and expires > 0) and (expires - GetTime()) or 999
            return true, (count and count > 0) and count or 1, left
        end
    end
    return false, 0, 0
end

---------------------------------------------------------------------------
-- Контекст для правил
---------------------------------------------------------------------------
local ctx = {}
ns.ctx = ctx

local function S(id) return SpellName(id) end
ns.S = S

-- WoW Forever = клиент Midnight: в бою часть данных «секретная» (HP, имена, ауры).
-- С секретными значениями нельзя сравнивать/считать — поэтому всё через safe():
-- если значение недоступно, берём безопасное значение по умолчанию.
local function safe(f, default)
    local ok, v = pcall(f)
    if not ok or v == nil then return default end
    if issecretvalue and issecretvalue(v) then return default end
    return v
end
ns.safe = safe

local function IsKnown(id)
    local n = S(id)
    if not n then return false end
    if known[n] then return true end
    if IsPlayerSpell and safe(function() return IsPlayerSpell(id) end, false) then return true end
    if IsSpellKnown and safe(function() return IsSpellKnown(id) end, false) then return true end
    if C_SpellBook and C_SpellBook.IsSpellKnown and safe(function() return C_SpellBook.IsSpellKnown(id) end, false) then return true end
    -- по имени: в современном клиенте инфо по имени отдаётся только для изученных заклинаний
    if C_Spell and C_Spell.GetSpellInfo and safe(function() return C_Spell.GetSpellInfo(n) ~= nil end, false) then return true end
    return false
end
ns.IsKnown = IsKnown
function ctx:Known(id)  return IsKnown(id) end
function ctx:Ready(id)  return IsKnown(id) and safe(function() local n = S(id); return (Usable(n) and CooldownLeft(n) == 0) or false end, false) end
function ctx:CD(id)     return safe(function() local n = S(id); return n and CooldownLeft(n) or 999 end, 999) end
-- Ауры: вне боя спрашиваем игру, в бою (там «секрет») — считаем сами по кастам
ns.AURA_DUR = {}   -- id -> длительность (заполняет файл класса)
local function TrackedAura(id, onTarget)
    local n = S(id); local dur = ns.AURA_DUR[id]
    local t
    if n then if onTarget then t = lastCastOnTarget[n] else t = lastCast[n] end end
    if not t or not dur then return false, 0, 0 end
    local left = t + dur - GetTime()
    if left <= 0 then return false, 0, 0 end
    return true, (n == S(7386) and sunderStacks or 1), left
end
function ctx:Buff(id)
    if not InCombatLockdown() then
        local ok, has, n, left = pcall(Aura, "player", S(id), "HELPFUL")
        if ok then return has, n, left end
    end
    return TrackedAura(id, false)
end
function ctx:Debuff(id)
    if not InCombatLockdown() then
        local ok, has, n, left = pcall(Aura, "target", S(id), "HARMFUL")
        if ok then return has, n, left end
    end
    return TrackedAura(id, true)
end
function ctx:Queued(id) return safe(function() local n = S(id); return n and IsCurrentSpell and IsCurrentSpell(n) or false end, false) end
function ctx:Range(id, unit) return safe(function() local n = S(id); return n and InRange(n, unit or "target") end, nil) end

local function ItemEquipLoc(itemID)
    if C_Item and C_Item.GetItemInfoInstant then return select(4, C_Item.GetItemInfoInstant(itemID)) end
    if GetItemInfoInstant then return select(4, GetItemInfoInstant(itemID)) end
    return select(9, GetItemInfo(itemID))
end

local function SnapshotPlayerAuras()
    -- вне боя баффы видны: запоминаем, сколько им осталось, чтобы в бою считать дальше самим
    if InCombatLockdown() then return end
    for id, dur in pairs(ns.AURA_DUR) do
        local n = S(id)
        if n then
            local ok, has, _, left = pcall(Aura, "player", n, "HELPFUL")
            if ok and has and left and left < 900 then lastCast[n] = GetTime() - (dur - left) end
        end
    end
end

local function UpdateContext()
    SnapshotPlayerAuras()
    ctx.hasTarget  = safe(function() return UnitExists("target") and UnitCanAttack("player", "target") and not UnitIsDead("target") end, false)
    ctx.combat     = safe(function() return UnitAffectingCombat("player") end, false)
    ctx.autoAttack = ns.autoAttack or safe(function() return IsCurrentSpell(6603) end, false)
    ctx.hp         = safe(function() return UnitHealth("player") / math.max(1, UnitHealthMax("player")) * 100 end, 100)
    ctx.thp        = ctx.hasTarget and safe(function() return UnitHealth("target") / math.max(1, UnitHealthMax("target")) * 100 end, 100) or 100
    ctx.power      = safe(function() return UnitPower("player") end, nil)   -- nil = в бою скрыто
    -- Оценка ярости по тому, на какие умения её хватает (флаг noMana не секретный)
    ctx.rageMin, ctx.rageMax = 0, 999
    for id, cost in pairs(ns.COSTS or {}) do
        if cost > 0 and IsKnown(id) then
            local ok, usable, noMana = pcall(Usable, S(id))
            if ok and not (issecretvalue and (issecretvalue(usable) or issecretvalue(noMana))) then
                if usable and cost > ctx.rageMin then ctx.rageMin = cost end
                if noMana and cost - 1 < ctx.rageMax then ctx.rageMax = cost - 1 end
            end
        end
    end
    if ctx.power then ctx.rageMin, ctx.rageMax = ctx.power, ctx.power end
    if ctx.rageMax < ctx.rageMin then ctx.rageMax = ctx.rageMin end
    ctx.stance     = safe(function() return GetShapeshiftForm() end, 0)
    ctx.tCombat    = ctx.hasTarget and safe(function() return UnitAffectingCombat("target") end, false)
    local cls      = ctx.hasTarget and safe(function() return UnitClassification("target") end, "normal") or "normal"
    ctx.elite      = cls == "elite" or cls == "rareelite" or cls == "worldboss"
    ctx.tLevelDiff = ctx.hasTarget and safe(function()
                        local l = UnitLevel("target"); if l <= 0 then l = 99 end
                        return l - UnitLevel("player") end, 0) or 0
    ctx.tType      = ctx.hasTarget and safe(function() return UnitCreatureType("target") end, "") or ""
    ctx.tCasting   = ctx.hasTarget and safe(function()
                        return ((UnitCastingInfo and UnitCastingInfo("target")) or (UnitChannelInfo and UnitChannelInfo("target"))) and true or false end, false)
    ctx.shield     = safe(function() local id = GetInventoryItemID("player", 17); if not id then return false end
                        return ItemEquipLoc(id) == "INVTYPE_SHIELD" end, false)
    -- сколько врагов в бою рядом (в мили)
    local n = 0
    local probe = ns.meleeProbe and S(ns.meleeProbe)
    if probe then
        for _, plate in ipairs(C_NamePlate.GetNamePlates()) do
            local u = plate.namePlateUnitToken
            -- «в бою ли моб» в Forever может быть скрыто — тогда считаем всех враждебных в мили
            local inCombat = safe(function() return UnitAffectingCombat(u) and true or false end, true)
            if u and inCombat and safe(function() return UnitCanAttack("player", u) and not UnitIsDead(u)
                                     and InRange(probe, u) == true end, false) then
                n = n + 1
            end
        end
    end
    if n == 0 and ctx.hasTarget and ctx.combat then n = 1 end
    ctx.enemies = n
end

---------------------------------------------------------------------------
-- Кнопки панелей: где лежит спелл и какая клавиша
---------------------------------------------------------------------------
local BARS = {
    { "ActionButton", "ACTIONBUTTON" },
    { "MultiBarBottomLeftButton", "MULTIACTIONBAR1BUTTON" },
    { "MultiBarBottomRightButton", "MULTIACTIONBAR2BUTTON" },
    { "MultiBarRightButton", "MULTIACTIONBAR3BUTTON" },
    { "MultiBarLeftButton", "MULTIACTIONBAR4BUTTON" },
    { "MultiBar5Button", "MULTIACTIONBAR5BUTTON" },
    { "MultiBar6Button", "MULTIACTIONBAR6BUTTON" },
    { "MultiBar7Button", "MULTIACTIONBAR7BUTTON" },
}

local function ShortKey(key)
    if not key then return nil end
    key = key:gsub("SHIFT%-", "S"):gsub("CTRL%-", "C"):gsub("ALT%-", "A")
             :gsub("NUMPAD", "N"):gsub("BUTTON", "M"):gsub("MOUSEWHEELUP", "MwU"):gsub("MOUSEWHEELDOWN", "MwD")
    return key
end

local FindButtonRaw
local function FindButton(spellName)
    local ok, b, k = pcall(FindButtonRaw, spellName)
    if ok then return b, k end
end
FindButtonRaw = function(spellName)
    for _, b in ipairs(BARS) do
        for i = 1, 12 do
            local btn = _G[b[1] .. i]
            if btn and btn:IsVisible() then
                local slot = btn.action or (ActionButton_GetPagedID and ActionButton_GetPagedID(btn))
                if slot and HasAction(slot) then
                    local kind, id = GetActionInfo(slot)
                    if kind == "spell" and S(id) == spellName then
                        return btn, ShortKey(GetBindingKey(b[2] .. i))
                    end
                end
            end
        end
    end
    -- стойки
    for i = 1, (GetNumShapeshiftForms and GetNumShapeshiftForms() or 0) do
        local _, _, _, sid = GetShapeshiftFormInfo(i)
        if sid and S(sid) == spellName then
            return _G["StanceButton" .. i], ShortKey(GetBindingKey("SHAPESHIFTBUTTON" .. i))
        end
    end
end

---------------------------------------------------------------------------
-- Окно подсказки
---------------------------------------------------------------------------
local frame = CreateFrame("Frame", "KaymanCoachFrame", UIParent, BackdropTemplateMixin and "BackdropTemplate")
frame:SetSize(64, 64)
frame:SetMovable(true); frame:SetClampedToScreen(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart", function(self) if not DB.locked then self:StartMoving() end end)
frame:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local p, _, rp, x, y = self:GetPoint(); DB.point = { p, "UIParent", rp, x, y }
end)

local function MakeIcon(parent, size)
    local b = CreateFrame("Frame", nil, parent)
    b:SetSize(size, size)
    b.icon = b:CreateTexture(nil, "ARTWORK"); b.icon:SetAllPoints(); b.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    b.border = b:CreateTexture(nil, "BACKGROUND"); b.border:SetColorTexture(0, 0, 0, 0.9)
    b.border:SetPoint("TOPLEFT", -2, 2); b.border:SetPoint("BOTTOMRIGHT", 2, -2)
    b.key = b:CreateFontString(nil, "OVERLAY", "NumberFontNormalLarge")
    b.key:SetPoint("TOPRIGHT", -2, -2)
    return b
end

frame.main = MakeIcon(frame, 64); frame.main:SetPoint("CENTER")
frame.main.key:SetFontObject("GameFontNormalHuge"); frame.main.key:SetTextColor(1, 0.85, 0.2)
frame.next1 = MakeIcon(frame, 34); frame.next1:SetPoint("BOTTOMLEFT", frame.main, "BOTTOMRIGHT", 8, 0)
frame.next2 = MakeIcon(frame, 34); frame.next2:SetPoint("LEFT", frame.next1, "RIGHT", 6, 0)
frame.next1:SetAlpha(0.75); frame.next2:SetAlpha(0.55)

frame.reason = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
frame.reason:SetPoint("TOP", frame.main, "BOTTOM", 0, -6)
frame.reason:SetWidth(320)

frame.rage = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
frame.rage:SetPoint("TOPLEFT", frame.main, "TOPRIGHT", 8, 0)

frame.talent = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
frame.talent:SetPoint("BOTTOM", frame.main, "TOP", 0, 8)
frame.talent:SetWidth(360)

-- подсветка кнопки на панели
local glow = CreateFrame("Frame", nil, UIParent)
glow:SetFrameStrata("HIGH")
glow.tex = glow:CreateTexture(nil, "OVERLAY")
glow.tex:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
glow.tex:SetBlendMode("ADD"); glow.tex:SetVertexColor(1, 0.85, 0.2)
glow.tex:SetAllPoints()
glow:Hide()
local pulse = 0
glow:SetScript("OnUpdate", function(self, dt)
    pulse = pulse + dt * 5
    self.tex:SetAlpha(0.55 + 0.45 * math.sin(pulse))
end)

local function SetIcon(b, rule)
    if not rule then b:Hide(); return end
    b.icon:SetTexture(SpellIcon(rule.id))
    local _, key = FindButton(S(rule.id))
    b.key:SetText(key or "")
    b:Show()
end

---------------------------------------------------------------------------
-- Главный цикл
---------------------------------------------------------------------------
local rules, talentPlan
local elapsed = 0

local function Evaluate()
    UpdateContext()
    local out = {}
    local seen = {}
    -- Если в клиенте есть встроенный помощник ротации Blizzard — его совет идёт первым
    if DB.blizzard and C_AssistedCombat and C_AssistedCombat.GetNextCastSpell then
        local id = safe(function()
            if C_AssistedCombat.IsAvailable and not C_AssistedCombat.IsAvailable() then return nil end
            return C_AssistedCombat.GetNextCastSpell(false)
        end, nil)
        if id and id ~= 0 and ctx.hasTarget then
            table.insert(out, { id = id, why = "совет Blizzard" }); seen[S(id) or id] = true
        end
    end
    for _, r in ipairs(rules) do
        if not seen[S(r.id) or r.id] and ctx:Known(r.id) then
            local ok, res = pcall(r.when, ctx)
            if ok and res then
                table.insert(out, r); seen[S(r.id) or r.id] = true
                if #out == 3 then break end
            end
        end
    end
    return out
end

---------------------------------------------------------------------------
-- Запись боя: что советовал аддон и что нажал игрок (для разбора)
---------------------------------------------------------------------------
local fight, fightStart, lastLogged
local function Log(line)
    if not fight then return end
    if #fight.lines >= 400 then return end
    table.insert(fight.lines, string.format("%5.1f  %s", GetTime() - fightStart, line))
end
ns.Log = Log
local function FightStart()
    if not DB.record then return end
    fightStart = GetTime(); lastLogged = nil
    local tname = safe(function() return UnitName("target") end, "?")
    local tlvl = safe(function() return UnitLevel("target") end, "?")
    fight = { started = date("%Y-%m-%d %H:%M:%S"), target = tostring(tname) .. " (" .. tostring(tlvl) .. ")", lines = {} }
    Log("=== БОЙ НАЧАЛСЯ, цель: " .. fight.target)
end
local function FightEnd()
    if not fight then return end
    Log("=== БОЙ ЗАКОНЧИЛСЯ")
    DB.fights = DB.fights or {}
    table.insert(DB.fights, fight)
    while #DB.fights > 15 do table.remove(DB.fights, 1) end
    fight = nil
end

local function Refresh()
    if not rules then frame:Hide(); glow:Hide(); return end
    if DB.onlyCombat and not UnitAffectingCombat("player") then frame:Hide(); glow:Hide(); return end
    if not UnitExists("target") or not UnitCanAttack("player", "target") or UnitIsDead("target") then
        -- без цели показываем только баффы (например, Боевой крик)
    end
    local list = Evaluate()
    if fight then
        local sug = list[1] and S(list[1].id) or (ctx.combat and "(жди, копи ярость)" or "—")
        local rage = ctx.power and tostring(ctx.power) or (ctx.rageMax >= 999 and ("≥" .. ctx.rageMin) or (ctx.rageMin .. "–" .. ctx.rageMax))
        local key = sug .. rage .. ctx.enemies .. ctx.stance
        if key ~= lastLogged then
            lastLogged = key
            Log(string.format("СОВЕТ %-22s ярость %-6s врагов %d стойка %d%s", sug, rage, ctx.enemies, ctx.stance,
                list[2] and ("  дальше: " .. tostring(S(list[2].id))) or ""))
        end
    end
    if #list == 0 then frame.main:Hide(); frame.next1:Hide(); frame.next2:Hide(); glow:Hide()
        if ctx.combat and ctx.hasTarget then
            -- в бою, но жать нечего: честно говорим «жди»
            frame.reason:SetText("|cffaaaaaaавтоатака идёт — копи ярость, ничего не жми|r")
            frame.rage:SetText(""); frame:Show()
        else
            frame.reason:SetText("")
            frame:SetShown(not DB.locked or frame.talent:GetText() ~= "")
        end
        return end
    frame:Show()
    if ctx.power then frame.rage:SetText("")
    elseif ctx.rageMax >= 999 then frame.rage:SetText("|cffff6060ярость ≥ " .. ctx.rageMin .. "|r")
    else frame.rage:SetText("|cffff6060ярость " .. ctx.rageMin .. "–" .. ctx.rageMax .. "|r") end
    SetIcon(frame.main, list[1]); SetIcon(frame.next1, list[2]); SetIcon(frame.next2, list[3])
    local why = list[1].why
    if type(why) == "function" then why = why(ctx) end
    frame.reason:SetText(DB.reason and ("|cffffd100" .. S(list[1].id) .. "|r — " .. (why or "")) or "")

    local btn = DB.glow and FindButton(S(list[1].id))
    if btn then
        glow:ClearAllPoints()
        glow:SetPoint("TOPLEFT", btn, "TOPLEFT", -14, 14)
        glow:SetPoint("BOTTOMRIGHT", btn, "BOTTOMRIGHT", 14, -14)
        glow:Show()
    else
        glow:Hide()
    end
end

frame:SetScript("OnUpdate", function(_, dt)
    elapsed = elapsed + dt
    if elapsed < 0.1 then return end
    elapsed = 0
    Refresh()
end)

---------------------------------------------------------------------------
-- Таланты (как билд в доте)
---------------------------------------------------------------------------
local function TalentHint()
    frame.talent:SetText("")
    if not DB.talents or not talentPlan or not talentPlan.byLevel then return end
    local lvl = safe(function() return UnitLevel("player") end, 0)
    -- Если клиент умеет говорить о свободных очках — подсказываем, куда вложить самое раннее из них.
    -- Если нет (в Forever API талантов другой) — подсказываем сразу после получения уровня.
    local points = UnitCharacterPoints and safe(function() return UnitCharacterPoints("player") end, nil) or nil
    local forLevel
    if points and points > 0 then forLevel = lvl - points + 1
    elseif points == nil and ns.justLeveled then forLevel = lvl end
    if not forLevel or forLevel < 10 then return end
    local entry = talentPlan.byLevel[forLevel]
    local msg
    if entry then
        msg = string.format("Талант за %d ур.: |cff33ff33%s|r → %s", forLevel, talentPlan.tabName, entry)
    else
        msg = "Талант: план расписан до 30 ур. — дальше обновлю"
    end
    frame.talent:SetText(msg)
    return msg
end

---------------------------------------------------------------------------
-- События
---------------------------------------------------------------------------
local ev = CreateFrame("Frame")
-- в Forever часть старых событий убрана — регистрируем каждое отдельно, лишние пропускаем
for _, e in ipairs({ "ADDON_LOADED", "PLAYER_LOGIN", "SPELLS_CHANGED", "LEARNED_SPELL_IN_TAB",
                     "LEARNED_SPELL_IN_SKILL_LINE", "PLAYER_LEVEL_UP", "CHARACTER_POINTS_CHANGED",
                     "UNIT_SPELLCAST_SUCCEEDED", "PLAYER_TARGET_CHANGED", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED",
                     "PLAYER_ENTER_COMBAT", "PLAYER_LEAVE_COMBAT" }) do
    pcall(ev.RegisterEvent, ev, e)
end

ev:SetScript("OnEvent", function(_, e, arg1, ...)
    if e == "ADDON_LOADED" and arg1 == ADDON then
        KaymanCoachDB = KaymanCoachDB or {}
        DB = KaymanCoachDB
        for k, v in pairs(defaults) do if DB[k] == nil then DB[k] = v end end
        frame:ClearAllPoints(); frame:SetPoint(unpack(DB.point)); frame:SetScale(DB.scale)
        frame:EnableMouse(not DB.locked)
        ns.DB, ns.frame, ns.TalentHint = DB, frame, TalentHint
        if ns.OnDBReady then pcall(ns.OnDBReady) end
    elseif e == "PLAYER_LOGIN" then
        local _, class = UnitClass("player")
        local c = ns.classes[class]
        if c then
            rules, talentPlan, ns.meleeProbe = c.rules, c.talents, c.meleeProbe
            ns.COSTS = c.costs
            for id, sec in pairs(c.cooldowns or {}) do local n = S(id); if n then cdByName[n] = sec end end
            for id, sec in pairs(c.auras or {}) do ns.AURA_DUR[id] = sec end
            print("|cffff4040Kayman Coach|r: " .. c.title .. ". Команды: |cffffff00/coach|r")
        else
            print("|cffff4040Kayman Coach|r: для этого класса правил пока нет.")
        end
        pcall(ScanSpellbook)
        local m = TalentHint(); if m then print("|cffff4040Kayman Coach|r: " .. m) end
    elseif e == "SPELLS_CHANGED" or e == "LEARNED_SPELL_IN_TAB" or e == "LEARNED_SPELL_IN_SKILL_LINE" then
        pcall(ScanSpellbook)
    elseif e == "PLAYER_LEVEL_UP" then
        local lvl = arg1
        if lvl and lvl % 2 == 0 then
            print("|cffff4040Kayman Coach|r: |cffffff00" .. lvl .. " уровень — загляни к тренеру, есть новые умения/ранги!|r")
            UIErrorsFrame:AddMessage("Уровень " .. lvl .. ": пора к тренеру!", 1, 0.85, 0.2)
        end
        ns.justLeveled = true
        C_Timer.After(1, function() local m = TalentHint(); if m then print("|cffff4040Kayman Coach|r: " .. m) end end)
        C_Timer.After(90, function() ns.justLeveled = false; TalentHint() end)
    elseif e == "UNIT_SPELLCAST_SUCCEEDED" then
        local unit, spellID = arg1, select(2, ...)
        if unit ~= "player" then return end
        local n = safe(function() return S(spellID) end, nil)
        if n then
            local now = GetTime()
            lastCast[n] = now; lastCastOnTarget[n] = now
            Log(">>> НАЖАЛ " .. n)
            if n == S(7386) then sunderStacks = math.min(5, sunderStacks + 1) end
        end
    elseif e == "PLAYER_ENTER_COMBAT" then      -- автоатака включилась
        ns.autoAttack = true; Log("автоатака ВКЛ")
    elseif e == "PLAYER_LEAVE_COMBAT" then      -- автоатака выключилась
        ns.autoAttack = false; Log("автоатака ВЫКЛ")
    elseif e == "PLAYER_REGEN_DISABLED" then
        FightStart()
    elseif e == "PLAYER_REGEN_ENABLED" then
        FightEnd()
    elseif e == "PLAYER_TARGET_CHANGED" then
        Log("смена цели")
        wipe(lastCastOnTarget); sunderStacks = 0
    elseif e == "CHARACTER_POINTS_CHANGED" then
        TalentHint()
    end
end)

---------------------------------------------------------------------------
-- /coach
---------------------------------------------------------------------------
local function onoff(v) return v and "|cff33ff33вкл|r" or "|cffff3333выкл|r" end
ns.Slash = function(msg)
    msg = (msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
    local p = "|cffff4040Kayman Coach:|r "
    local cmd, arg = msg:match("^(%S*)%s*(.*)$")
    if (cmd == "" or cmd == "menu" or cmd == "меню") and ns.ToggleOptions then
        ns.ToggleOptions(); return
    elseif cmd == "raw" then
        local function show(label, f)
            local ok, a, b = pcall(f)
            local function fmt(v)
                if issecretvalue and issecretvalue(v) then return "|cffff4040СЕКРЕТ|r" end
                return tostring(v)
            end
            print("  " .. label .. ": " .. (ok and (fmt(a) .. (b ~= nil and (" / " .. fmt(b)) or "")) or ("|cffff4040ОШИБКА|r " .. tostring(a))))
        end
        print(p .. "RAW (сделай это В БОЮ), бой=" .. tostring(InCombatLockdown()))
        show("ярость UnitPower", function() return UnitPower("player") end)
        show("HP цели", function() return UnitHealth("target") end)
        show("Assisted Combat доступен", function() return C_AssistedCombat and C_AssistedCombat.IsAvailable and C_AssistedCombat.IsAvailable() end)
        show("Assisted Combat совет", function() return C_AssistedCombat and C_AssistedCombat.GetNextCastSpell and C_AssistedCombat.GetNextCastSpell(false) end)
        for _, id in ipairs({ 78, 6572, 2687, 1715 }) do   -- Удар героя, Реванш, Кровавая ярость, Подрезать
            local n = S(id)
            show(tostring(n) .. " usable", function() return Usable(n) end)
            show(tostring(n) .. " cooldown", function()
                if GetSpellCooldown then local a, b = GetSpellCooldown(n); return a, b end
                local c = C_Spell.GetSpellCooldown(n); return c and c.startTime, c and c.duration end)
            show(tostring(n) .. " range", function() return InRange(n, "target") end)
        end
        return
    elseif cmd == "debug" then
        local _, class = UnitClass("player")
        local n = 0; for _ in pairs(known) do n = n + 1 end
        print(p .. "DEBUG класс " .. tostring(class) .. ", правил: " .. (rules and #rules or 0) .. ", заклинаний в книге найдено: " .. n)
        print("  C_AssistedCombat: " .. tostring(C_AssistedCombat ~= nil) .. ", интерфейс " .. tostring(select(4, GetBuildInfo())))
        UpdateContext()
        print(string.format("  цель=%s бой=%s HP=%s ярость=%s (оценка %s–%s) стойка=%s щит=%s врагов=%s",
            tostring(ctx.hasTarget), tostring(ctx.combat), tostring(math.floor(ctx.hp)), tostring(ctx.power), tostring(ctx.rageMin), tostring(ctx.rageMax),
            tostring(ctx.stance), tostring(ctx.shield), tostring(ctx.enemies)))
        for _, r in ipairs(rules or {}) do
            local ok, res = pcall(r.when, ctx)
            print(string.format("  %s [%d]: знаю=%s готово=%s условие=%s", tostring(S(r.id)), r.id,
                tostring(IsKnown(r.id)), tostring(ctx:Ready(r.id)), ok and tostring(res) or ("ОШИБКА " .. tostring(res))))
        end
        return
    elseif cmd == "unlock" or cmd == "move" then
        DB.locked = false; frame:EnableMouse(true); frame:Show()
        print(p .. "окно разблокировано — тащи мышкой. |cffffff00/coach lock|r — закрепить.")
    elseif cmd == "lock" then
        DB.locked = true; frame:EnableMouse(false); print(p .. "окно закреплено.")
    elseif cmd == "scale" and tonumber(arg) then
        DB.scale = tonumber(arg); frame:SetScale(DB.scale); print(p .. "масштаб " .. DB.scale)
    elseif cmd == "glow" then
        DB.glow = not DB.glow; print(p .. "подсветка кнопки " .. onoff(DB.glow))
    elseif cmd == "why" then
        DB.reason = not DB.reason; print(p .. "пояснение " .. onoff(DB.reason))
    elseif cmd == "combat" then
        DB.onlyCombat = not DB.onlyCombat; print(p .. "показывать только в бою " .. onoff(DB.onlyCombat))
    elseif cmd == "rec" then
        DB.record = not DB.record; print(p .. "запись боёв " .. onoff(DB.record))
    elseif cmd == "clear" then
        DB.fights = {}; print(p .. "записи боёв очищены")
    elseif cmd == "blizzard" then
        DB.blizzard = not DB.blizzard; print(p .. "совет встроенного помощника Blizzard " .. onoff(DB.blizzard))
    elseif cmd == "plan" then
        print(p .. "план талантов (" .. (talentPlan and talentPlan.source or "?") .. "):")
        for l = 10, 60 do local e = talentPlan and talentPlan.byLevel[l]; if e then print("  " .. l .. ": " .. e) end end
        return
    elseif cmd == "talents" then
        DB.talents = not DB.talents; TalentHint(); print(p .. "подсказки талантов " .. onoff(DB.talents))
    else
        print(p .. "команды (или просто |cffffff00/kc|r — открыть меню):")
        print("  /coach unlock | lock — двигать окно     /coach scale 1.2 — размер")
        print("  /coach glow — подсветка кнопки     /coach why — пояснение под иконкой")
        print("  /coach combat — только в бою     /coach talents — подсказки талантов")
        print("  /coach debug — диагностика (пришли скрин чата, если что-то не работает)")
        print("  /kc plan — весь план талантов по уровням")
        print("  /kc rec — запись боёв (вкл по умолчанию)   /kc clear — стереть записи")
        print("  /coach blizzard — использовать встроенный помощник ротации Blizzard (если есть)")
    end
end

end, LoadErr)
if not okLoad then
    ns.loadError = errLoad
    print("|cffff4040Kayman Coach не загрузился:|r " .. tostring(errLoad))
end
